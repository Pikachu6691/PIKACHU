# txAdminRecipe

**Description:** Complete RP Server For FiveM based on QBCore. 

This recipe runs inside [**txAdmin**](https://github.com/tabarra/txAdmin).  
Please check the [**Recipe Documentation Page**](https://github.com/tabarra/txAdmin/blob/master/docs/recipe.md).
