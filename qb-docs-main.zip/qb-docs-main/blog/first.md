---
slug: welcome
title: Welcome
author: Kakarot - Josh
author_title: QBCore Framework Maintainer
author_url: https://github.com/GhzGarage
author_image_url: https://cdn.discordapp.com/avatars/793379017062350888/097b814a53bbd91192dcad818e00b0cd.png?size=2048
---

Thanks for checking out the QBCore documentation! I'm hoping to keep it as maintained as possible and possibly make occassional tutorial posts here in the blog section to better explain some of the functions and events!